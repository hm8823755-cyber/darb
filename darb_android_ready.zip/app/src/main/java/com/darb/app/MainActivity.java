package com.darb.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    int yellow = Color.rgb(255,193,7);
    int dark = Color.rgb(23,23,23);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    TextView tv(String text, int size, int color) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        t.setPadding(16,12,16,12);
        return t;
    }

    Button btn(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextSize(16); b.setTextColor(Color.BLACK);
        b.setAllCaps(false); b.setBackgroundColor(yellow);
        return b;
    }

    void base(LinearLayout box) {
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(18,18,18,18);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
    }

    void showHome() {
        LinearLayout root = new LinearLayout(this); base(root);
        TextView title = tv("دَرب\nأسهل طريق لك", 25, dark);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1,90));

        TextView promo = tv("🎁 عرض المستخدم الجديد\nأول رحلة تكسي مجانية\n\n🍔 توصيل أكل مجاني على العروض المؤهلة", 20, Color.WHITE);
        promo.setBackgroundColor(dark);
        root.addView(promo, new LinearLayout.LayoutParams(-1,190));

        Space s = new Space(this); root.addView(s,new LinearLayout.LayoutParams(1,18));

        Button taxi = btn("🚕  اطلب تكسي");
        taxi.setOnClickListener(v -> showTaxi());
        root.addView(taxi,new LinearLayout.LayoutParams(-1,62));

        Button food = btn("🍔  توصيل أكل");
        food.setOnClickListener(v -> showFood());
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1,62); fp.topMargin=12;
        root.addView(food,fp);

        Button offers = btn("🎁  الخصومات والعروض");
        offers.setOnClickListener(v -> showOffers());
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1,62); op.topMargin=12;
        root.addView(offers,op);

        TextView note = tv("الرئيسية     |     طلباتي     |     العروض     |     حسابي", 14, Color.DKGRAY);
        note.setGravity(Gravity.CENTER);
        root.addView(note,new LinearLayout.LayoutParams(-1,70));

        setContentView(root);
    }

    void header(LinearLayout root, String name) {
        Button back=btn("‹ رجوع");
        back.setOnClickListener(v->showHome());
        root.addView(back,new LinearLayout.LayoutParams(-1,55));
        TextView h=tv(name,25,dark); h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        root.addView(h,new LinearLayout.LayoutParams(-1,70));
    }

    void showTaxi() {
        LinearLayout root=new LinearLayout(this); base(root); header(root,"🚕 طلب تكسي");
        root.addView(tv("📍  من أين؟\nموقعك الحالي",18,dark),new LinearLayout.LayoutParams(-1,85));
        root.addView(tv("📍  إلى أين؟\nاختر وجهتك",18,dark),new LinearLayout.LayoutParams(-1,85));
        root.addView(tv("🚗 السيارة: عادية\n💰 السعر التقريبي: يظهر بعد تحديد المسار",17,dark));
        Button go=btn("اطلب التكسي الآن");
        go.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("دَرب").setMessage("تم إرسال طلب التكسي التجريبي 🚕")
            .setPositiveButton("حسناً",null).show());
        root.addView(go,new LinearLayout.LayoutParams(-1,65));
        setContentView(root);
    }

    void showFood() {
        LinearLayout root=new LinearLayout(this); base(root); header(root,"🍔 توصيل الأكل");
        root.addView(tv("ابحث عن مطعم أو وجبة",18,dark),new LinearLayout.LayoutParams(-1,65));
        String[] restaurants={"مطعم دَرب — برغر وبيتزا","مطعم الموصل — وجبات وعروض","مطعم العائلة — وجبات سريعة"};
        for(String r:restaurants){
            Button b=btn("🍽️  "+r+"\n🛵 توصيل مجاني على العرض");
            root.addView(b,new LinearLayout.LayoutParams(-1,75));
        }
        setContentView(root);
    }

    void showOffers() {
        LinearLayout root=new LinearLayout(this); base(root); header(root,"🎁 الخصومات والعروض");
        root.addView(tv("🔥 أول رحلة تكسي مجانية",20,dark),new LinearLayout.LayoutParams(-1,75));
        root.addView(tv("🛵 توصيل أكل مجاني\nللطلبات والمطاعم المشمولة بالعرض",19,dark),new LinearLayout.LayoutParams(-1,100));
        root.addView(tv("🎟️ كوبونات خصم\n⭐ نقاط ومكافآت للمستخدمين",19,dark),new LinearLayout.LayoutParams(-1,100));
        setContentView(root);
    }
}
